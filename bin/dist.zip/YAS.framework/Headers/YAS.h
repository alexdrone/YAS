#import <Foundation/Foundation.h>

#import <YAS/yaml.h>
#import <YAS/YASObjcExceptionHandler.h>

FOUNDATION_EXPORT double YASVersionNumber;
FOUNDATION_EXPORT const unsigned char YASVersionString[];
